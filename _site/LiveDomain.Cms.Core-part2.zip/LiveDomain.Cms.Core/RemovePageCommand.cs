﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiveDomain.Core;

namespace LiveDomain.Cms.Core
{
    [Serializable]
    public class RemovePageCommand : Command<CmsModel>
    {

        public readonly Guid PageId;

        public RemovePageCommand(Guid pageId)
        {
            PageId = pageId;
        }

        protected override void Execute(CmsModel model)
        {
            try
            {
                model.RemovePage(PageId);
            }
            catch (InvalidOperationException)
            {
                throw new CommandFailedException("Can't delete page, no such pageId");
            }
        }
    }
}
