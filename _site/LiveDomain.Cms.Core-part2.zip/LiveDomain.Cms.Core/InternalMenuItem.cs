﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveDomain.Cms.Core
{
    [Serializable]
    public class InternalMenuItem : MenuItem
    {
        public Guid PageId { get; set; }
    }
}
