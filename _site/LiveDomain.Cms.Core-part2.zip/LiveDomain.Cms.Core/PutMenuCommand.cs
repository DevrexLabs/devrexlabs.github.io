﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiveDomain.Core;

namespace LiveDomain.Cms.Core
{
[Serializable]
public class PutMenuCommand : Command<CmsModel>
{
    public readonly Menu Menu;

    public PutMenuCommand(Menu menu)
    {
        if (menu == null)
            throw new ArgumentNullException("menu");
        Menu = menu;
    }

    protected override void Execute(CmsModel model)
    {
        model.PutMenu(Menu);
    }
}
}
