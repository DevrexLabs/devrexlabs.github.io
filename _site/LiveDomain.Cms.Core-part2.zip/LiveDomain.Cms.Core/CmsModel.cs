﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiveDomain.Core;

namespace LiveDomain.Cms.Core
{
[Serializable]
public class CmsModel : Model
{
    private IDictionary<Guid, Page> _pages;
    private Dictionary<string, Menu> _menus; 

    public CmsModel()
    {
        _pages = new Dictionary<Guid, Page>();
        _menus = new Dictionary<string, Menu>();
    }

    protected override void SnapshotRestored()
    {
        if (_menus == null) _menus = new Dictionary<string, Menu>();
    }

    public void PutMenu(Menu menu)
    {
        _menus[menu.Name] = menu;
    }

    public void RemoveMenu(string name)
    {
        if (!_menus.ContainsKey(name))
            throw new InvalidOperationException("Cant remove menu, no menu named " + name);
        _menus.Remove(name);
    }

    public void RemovePage(Guid pageId)
    {
        if (!_pages.ContainsKey(pageId)) 
            throw new InvalidOperationException("Can't remove page, no page with id " + pageId.ToString());
        _pages.Remove(pageId);
    }

    public void PutPage(Page page)
    {
        _pages[page.Id] = page;
    }
}
}
