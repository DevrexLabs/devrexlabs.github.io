﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveDomain.Cms.Core
{
    [Serializable]
    public class Page
    {
        public readonly Guid Id;
        public readonly DateTime Created;

        public string Title { get; set; }
        public string Contents { get; set; }

        public Page(Guid id, DateTime created)
        {
            Id = id;
            Created = created;
            Title = "Untitled page";
            Contents = String.Empty;
        }
    }
}
