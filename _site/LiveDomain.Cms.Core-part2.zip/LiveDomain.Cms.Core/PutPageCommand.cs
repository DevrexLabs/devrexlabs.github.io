﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiveDomain.Core;

namespace LiveDomain.Cms.Core
{
    [Serializable]
    public class PutPageCommand : Command<CmsModel>
    {

        public readonly Page Page;

        public PutPageCommand(Page page)
        {
            if (page == null) throw new ArgumentNullException("page");
            Page = page;
        }

        protected override void Execute(CmsModel model)
        {
            model.PutPage(Page);
        }
    }
}
