﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiveDomain.Core;

namespace LiveDomain.Cms.Core
{
[Serializable]
public class RemoveMenuCommand : Command<CmsModel>
{
    public readonly string MenuName;

    public RemoveMenuCommand(string menuName)
    {
        MenuName = menuName;
    }

    protected override void Execute(CmsModel model)
    {
        try
        {
            model.RemoveMenu(MenuName);
        }
        catch (InvalidOperationException)
        {
            throw new CommandFailedException("Cant delete menu, no such name:" + MenuName);
        }   
    }
}
}
