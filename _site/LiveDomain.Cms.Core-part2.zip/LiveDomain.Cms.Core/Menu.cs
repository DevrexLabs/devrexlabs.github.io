﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveDomain.Cms.Core
{
    [Serializable]
    public class Menu : MenuItem
    {
        public readonly IList<MenuItem> Items;

        public Menu()
        {
            Items = new List<MenuItem>();
        }
    }
}
