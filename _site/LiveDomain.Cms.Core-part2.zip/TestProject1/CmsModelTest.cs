﻿using LiveDomain.Cms.Core;
using LiveDomain.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject1
{


    /// <summary>
    ///This is a test class for CmsModelTest and is intended
    ///to contain all CmsModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CmsModelTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        [ExpectedException(typeof(InvalidOperationException))]
        [TestMethod()]
        public void RemovePage_fails_unless_page_exists()
        {
            var target = new CmsModel();
            target.RemovePage(Guid.NewGuid());
        }


        [TestMethod()]
        public void PageSmokeTest()
        {
            var engine = Engine.LoadOrCreate<CmsModel>("c:\\livedb\\cms");
            var page = new Page(Guid.NewGuid(), DateTime.Now);
            page.Contents = "Hello, world!";
            var command = new PutPageCommand(page);
            engine.Execute(command);
            engine.Close();
        }

[TestMethod()]
public void MenuSmokeTest()
{
    var engine = Engine.LoadOrCreate<CmsModel>("c:\\livedb\\cms");
    var page = new Page(Guid.NewGuid(), DateTime.Now);
    page.Contents = "Hello, world!";
    Command command = new PutPageCommand(page);
    engine.Execute(command);

    Menu menu = new Menu{Name = "_main"};
    menu.Items.Add(new ExternalMenuItem{ Name = "squash", Url = "http://psasquashtv.com/"});
    menu.Items.Add(new ExternalMenuItem{ Name = "livedb", Url = "http://livedb.devrex.se/"});
    menu.Items.Add(new InternalMenuItem{Name = page.Title, PageId = page.Id});
    var subMenu = new Menu(){Name = "Events"};
    menu.Items.Add(subMenu);
    subMenu.Items.Add(new ExternalMenuItem{ Name = "News", Url = "http://dn.se/"});

    command = new PutMenuCommand(menu);
    engine.Execute(command);
    engine.Close();
}

    }
}
